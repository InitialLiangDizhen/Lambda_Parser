module Main (main) where

main :: IO ()
main = putStrLn "Main function"
